import React from 'react'

function Title() {
  return (
    <div>
        <div className='titleContent'>
            <h3> Graphic Design</h3>
            <p>
            Praesent dignissm nibh quis ante dignissm, in posuere dui feugiat. duis elit dui, vestibulum nec ipsum id, finibus sollicitudin elit
            </p>
        </div>
      
    </div>
  )
}

export default Title
