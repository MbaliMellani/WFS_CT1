import React from 'react'


function Header() {
  return (
    <div id className='subheader'>
        <h2>
            Praesent dignissm nibh quis ante dignissm, in posuere dui feugiat. duis elit dui, vestibulum nec ipsum id, finibus sollicitudin elit. cras et purus sagittis, volutpat est id.
        </h2>
    </div>
  )
}

export default Header