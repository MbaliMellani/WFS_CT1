import React from 'react'
import Article2 from "/..Assets/pic-2.PNG"

function Article2() {
  return (
    <div>
      <article className='article2'></article>
      <h3>Web development</h3>
      Praesent dignissm nibh quis ante dignissm, in posuere dui feugiat. duis elit dui, vestibulum nec ipsum id, finibus sollicitudin elit. cras et purus sagittis, volutpat est id.
      <img src={Article2} alt= "pic-2.PNG"></img>
    
    </div>
  )
}

export default Article2
