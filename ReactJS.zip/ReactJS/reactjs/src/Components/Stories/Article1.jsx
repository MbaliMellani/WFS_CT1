import React from 'react'
import Article1 from "/..Assets/pic-1.PNG"

function Article1() {
  return (
    <div>
      <article className='article2'>
      <h3>Graphic design</h3>
      Praesent dignissm nibh quis ante dignissm, in posuere dui feugiat. duis elit dui, vestibulum nec ipsum id, finibus sollicitudin elit. cras et purus sagittis, volutpat est id.
      <img src={Article1} alt= "pic-1.PNG"></img>
      </article>
    </div>
    
    
  )
}

export default Article1

