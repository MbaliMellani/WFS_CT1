import React from 'react'

function Article3() {
  return (
    <div>
       <article className='article3'></article>
      <h3>Marketing</h3>
      Praesent dignissm nibh quis ante dignissm, in posuere dui feugiat. duis elit dui, vestibulum nec ipsum id, finibus sollicitudin elit. cras et purus sagittis, volutpat est id.
      <img src={Article3} alt= "pic-3.PNG"></img>
    </div>
  )
}

export default Article3
