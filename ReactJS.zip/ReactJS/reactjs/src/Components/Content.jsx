import React from 'react'
import Article1 from '../components/Stories/Article1.jsx.'
import Article2 from '../components/Stories/Article2.jsx'
import Article3 from '../components/Stories/Article3.jsx'


function Content() {
  return (
    <div>
      <Article1 />
      <Article2 />
      <Article3 />
    </div>
  )
}

export default Content
