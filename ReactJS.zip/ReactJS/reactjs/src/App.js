import React from 'react'
import './App.css';
import Header from './Components/Header';
import Content from './Components/Content';
import Title from './Components/Title';

function App() {
  return (
    <div>
      <Header />
      <Content />
      <Title />
    </div>
  )
}

export default App